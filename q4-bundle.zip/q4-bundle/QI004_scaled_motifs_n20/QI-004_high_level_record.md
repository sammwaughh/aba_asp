# QI-004 — Scaled noisy motifs with parent-position controls (reduced n=20)

## Status

`run` (raw output available; interpretation pending).

The ABA Learning grid run completed 2026-06-12: 15/15 cells produced `metrics.json` with **no timeouts** (1 solved, 12 completed_no_solution, 2 binary `unknown constant` errors; `clean_recovery = 0` for all cells). The full per-cell table and audit are in `QI004_scaled_motifs_n20/run_log.md`; interpretation is deferred.

## Why QI-004 exists

QI-004 is the computationally feasible follow-up to **QI-003**. The QI-003 `n=100` run was infeasible under the available Prolog timeout budget: cat3/cont3 cells timed out at 120s and binary cells hit the all-zero-positive BK encoding limitation, with 0 cells solved before manual abort (see `QI003_scaled_motifs/run_log.md`). QI-004 keeps the **same conceptual design** as QI-003 — same 5 structural configs x 3 data modes (15 cells), same parent-position controls breaking the x0 confound, same mechanisms and noise levels, same target `x2` — but changes only the two computational-feasibility settings:

- sample size: `n = 100` → `n = 20` (via a new fixtures module `handcrafted_qi004.py`);
- Prolog timeout: `prolog_timeout_s = 120` → `prolog_timeout_s = 300`.

This is an ABA Learning-based parent-set recovery investigation, NOT Russo-style Causal ABA.

## Research question

> With `n=20` noisy samples from 3-node motifs, and the true direct parent of `x2` placed in either column, does the current ABA Learning bridge recover the true parent(s) of `x2` regardless of column position, and how does recovery depend on data mode (binary / categorical-3 / continuous-3)?

## Theoretical motivation

- **ABA foundations:** assumptions, contraries, attacks, extensions.
- **ABA Learning / ABALearn:** transformation-rule learning from BK + E+/E-.
- **Causal ABA / argumentative causal discovery:** Russo-style machinery — NOT used here.
- **Current `aba_asp/causal` implementation:** target-wise learned-rule / parent-set recovery over `handcrafted_table` fixtures.

The confound logic is identical to QI-003: in QI-001 the true parent coincided with the first column for fork and opposed it for chain, so "found the cause" and "preferred x0" made identical predictions. Varying the parent's column position makes the two hypotheses distinguishable.

## Relation to ABA Learning

- BK built from non-target columns; target `x2` excluded.
- E+/E- fixed by the fixture (positive class = `x2 == 1` binary, `x2 == 2` cat3, `x2 >= 0` cont3).
- Target predicate: `x2`.
- Learner config: default non-deterministic folding, `folding_steps: 15`.

## Relation to Causal ABA

Tests whether learned ABA rule bodies recover causal-parent-like structure under scale, noise, and position controls. Does NOT test full Russo-style Causal ABA.

## Implementation scope

### Code/config paths

- Config path: `causal/configs/experiments/QI004_scaled_motifs_n20.yaml`
- Fixtures: `causal/experiments/handcrafted_qi004.py`
- Fixture registration: `causal/experiments/handcrafted.py`
- Summary script: `causal/scripts/motif_recovery_summary.py`
- Generated summary: `docs/experiments/qualitative/QI004_scaled_motifs_n20_summary.md`
- Output path: `causal/outputs/aba_learning/grid/QI004_scaled_motifs_n20/`

### Files changed

- `causal/experiments/handcrafted_qi004.py` (new; `_N=20`, reuses N-agnostic helpers from `handcrafted_qi003`)
- `causal/experiments/handcrafted.py` (register QI-004 builders)
- `causal/configs/experiments/QI004_scaled_motifs_n20.yaml` (new)
- `causal/tests/test_qi004_fixtures.py` (new)

## Dataset / data-generating process

### Source

- handcrafted fixture; programmatic `n=20` generators with a fixed per-fixture RNG seed (deterministic). The `handcrafted_table` path ignores `cell.seed`, so determinism comes from the builder seed.

### Graph / structure and parent-position tracking

```text
qi004_chain_x1parent : x0=root,   x1=parent  -> edges (0,1),(1,2)  parents(x2)={x1}
qi004_chain_x0parent : x1=root,   x0=parent  -> edges (1,0),(0,2)  parents(x2)={x0}
qi004_fork_x0parent  : x0=cause,  x1=sibling -> edges (0,1),(0,2)  parents(x2)={x0}
qi004_fork_x1parent  : x1=cause,  x0=sibling -> edges (1,0),(1,2)  parents(x2)={x1}
qi004_collider       : x0,x1 both parents     -> edges (0,2),(1,2)  parents(x2)={x0,x1}
```

5 structural configs x 3 data modes = 15 cells.

### Sample sizes

- `n = 20` per cell (reduced from QI-003's `n=100` for tractability).

### Seeds

- Deterministic per-fixture internal seed (`_BASE_SEED + i*10 + j`, `_BASE_SEED=20040000`); grid `seed: [0]`.

### Noise / stochasticity

- chain: intermediate flips from root with prob ~0.2 (breaks collinearity); target flips from parent with prob ~0.1 (binary/cat3) or Gaussian noise (cont3).
- fork: sibling noisier (~0.2) than the x2 target (~0.1) relative to the cause.
- collider: independent parents; `x2 = OR` (binary), `max` (cat3), or sum + Gaussian (cont3).

(Identical mechanisms/noise to QI-003; only `n` differs.)

## Encoding

### Target variable(s)

| Target | True parents | Target type | Reason for inclusion |
|---|---|---|---|
| `x2` | per-fixture (see tracking table) | has-parents / collider | the recovery target |

### Background knowledge

- Target excluded from BK: `yes`
- Binary features (`{0,1}`): bare predicates `x0(A)`
- 3-valued discrete features: value predicates `x0_val_v(A)`
- Continuous features: bin predicates `x0_binK(A)` (`bins=3`, `bin_strategy=uniform`)

### Known carry-over limitation (binary encoding)

The binary "positive-cases-only" BK encoding cannot declare a sample-id constant for an all-zero-feature row (`x0=0, x1=0`); target noise can flip such a row into a positive example, which then trips `check_ep_consts_aux` in `aba_asp.pl` (`ERROR: unknown constant`). Reducing `n` to 20 lowers but does not eliminate the chance. Per the prior decision this is RECORDED as a limitation, not fixed in this line of runs; per-cell status records it where it occurs.

## Commands run

```bash
# Prolog-free validation
python -m pytest causal/tests/test_qi004_fixtures.py -q
python -m causal.experiments.run_grid --config causal/configs/experiments/QI004_scaled_motifs_n20.yaml --dry-run   # 15 cells

# ABA Learning run
python -m causal.experiments.run_grid --config causal/configs/experiments/QI004_scaled_motifs_n20.yaml --no-resume
python causal/scripts/motif_recovery_summary.py --experiment QI004_scaled_motifs_n20
```

## Artefact paths

| Artefact | Path | Notes |
|---|---|---|
| Config | `causal/configs/experiments/QI004_scaled_motifs_n20.yaml` | 15 cells, `prolog_timeout_s=300` |
| Output root | `causal/outputs/aba_learning/grid/QI004_scaled_motifs_n20/` | run output |
| Summary markdown | `docs/experiments/qualitative/QI004_scaled_motifs_n20_summary.md` | regenerate via script |
| Operational dossier | `docs/experiments/qualitative/QI004_scaled_motifs_n20/` | README incl. parent-position tracking table |

## Outcome summary

15/15 cells completed within the 300s Prolog budget (no timeouts; max wall-clock 272.8s). Aggregate outcomes: 1 `solved`, 12 `completed_no_solution`, 2 `error` (both binary, `unknown constant` all-zero-positive encoding limitation). `clean_recovery = 0` for every cell. The single solved cell (`qi004_chain_x1parent_binary`) recovered `x1` (`var_parent_recall = 1.00`) but also cited a non-parent (`var_parent_precision = 0.50`), so it is not a clean recovery. See `QI004_scaled_motifs_n20/run_log.md` for the full per-cell table. Interpretation is deferred.

## Claims supported

- (Pending interpretation; raw outputs recorded in the dossier.)

## Claims not supported

- Full Causal ABA; causal discovery; DAG recovery; necessarily-causal rule direction.

## Report relevance

- Interim Experimentation / Progress: the scaled, confound-controlled evidence at a feasible `n`; the headline `clean_recovery` rate by data mode and by parent position. QI-003 is cited only as a computational-feasibility attempt that motivated the reduced-`n` design.

## Next decision

Review the QI-004 raw outputs, then fill the dossier `interpretation.md`. The `*_x1parent` vs `*_x0parent` comparison is the decision-critical confound check.
